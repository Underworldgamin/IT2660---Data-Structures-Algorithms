# Implement a HashMap using Hashing using the examples in 27.7. 

**Step 1:** Complete MyMap.java using LiveExample 27.1.

**Step 2:** Complete MyHashMap.java using LiveExample 27.2.

*In the main() method in Main.java:*

**Step 3:** Create a map valled creditHours.

**Step 4:** put() the following values:
* IT-1025, 3
* IT-1050, 3
* IT-1150, 3
* IT-2310, 3
* IT-2320, 4
* IT-2351, 4
* IT-2650, 4
* IT-2660, 4
* IT-2030, 4

**Step 5:** Check for the following values. Didsplay true of false depending on whether or not the map has the key.
* IT-1025
* IT-2110

**Step 6:** Print all of the values in the map.

  **Step 7:** Remove IT-2030 and IT-1150.

**Step 8:** Print all of the values in the map.